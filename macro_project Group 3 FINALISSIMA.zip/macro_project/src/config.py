"""
*******************************
Authors:    u3320473, u3218103, u3313879
Group:      Group 3 - Software Technology 1 (4483)
Assessment: Assignment 3 - Macroinvertebrate Image Analysis System
File:       config.py - Central configuration and path settings
Date:       20/05/2025
*******************************
"""
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

RAW_DATA_DIR = BASE_DIR / "data" / "raw"
EDA_OUTPUT_DIR = BASE_DIR / "outputs" / "eda"
MODEL_OUTPUT_DIR = BASE_DIR / "outputs" / "model"

IMAGE_SIZE = (128, 128) # Resize images to 128x128 pixels
SUPPORTED_IMAGE_FORMATS = [".jpg", ".jpeg", ".png", ".bmp", ".tiff"]