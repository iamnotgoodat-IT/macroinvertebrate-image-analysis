"""
*******************************
Authors:    u3320473, u3218103, u3313879
Group:      Group 3 - Software Technology 1 (4483)
Assessment: Assignment 3 - Macroinvertebrate Image Analysis System
File:       main.py - Backend verification and testing script
Date:       20/05/2025
*******************************
"""
from src.services.dataset_indexer import DatasetIndexer

def main():
    print("Scanning dataset...")
    indexer = DatasetIndexer()

    try:
        df = indexer.build_dataframe()
        summary = indexer.get_summary()

        print("Dataset Summary:")
        print(f"Total Images: {summary['total_images']}")
        print(f"Total Classes: {summary['total_classes']}")
        print(f"Average width: {summary['average_width']} pixels")
        print(f"Average height: {summary['average_height']} pixels")
        print(f"Classes found : {indexer.get_class_names()}")
        print(f"First 5 rows:\n{df.head()}")

    except FileNotFoundError as error:
        print(f"Error: {error}")
    
if __name__ == "__main__":
    main()