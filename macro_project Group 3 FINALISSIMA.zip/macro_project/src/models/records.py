"""
*******************************
Authors:    u3320473, u3218103, u3313879
Group:      Group 3 - Software Technology 1 (4483)
Assessment: Assignment 3 - Macroinvertebrate Image Analysis System
File:       records.py - ImageRecord dataclass definition
Date:       20/05/2025
*******************************
"""
from dataclasses import dataclass
from pathlib import Path

@dataclass
class ImageRecord:
    """Data class to represent an image record with its path and label."""

    file_path: Path
    label: str
    width: int
    height: int
    channels: int

    def aspect_ratio(self) -> float:
        """Calculate and return the aspect ratio of the image."""
        if self.height == 0:
            return 0.0
        return self.width / self.height
    
    def is_color(self) -> bool:
        """Determine if the image is color (has more than 1 channel)."""
        return self.channels == 3