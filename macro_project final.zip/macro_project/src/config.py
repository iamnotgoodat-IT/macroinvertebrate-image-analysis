# Config.py
# So I'll use pandas, numpy, opencv-python, matpotlib, Pillow
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

RAW_DATA_DIR = BASE_DIR / "data" / "raw"
EDA_OUTPUT_DIR = BASE_DIR / "outputs" / "eda"
MODEL_OUTPUT_DIR = BASE_DIR / "outputs" / "model"

IMAGE_SIZE = (128, 128) # Resize images to 128x128 pixels
SUPPORTED_IMAGE_FORMATS = [".jpg", ".jpeg", ".png", ".bmp", ".tiff"]