# eda_service.py
# Person 2 - Visualization & Image Specialist
# Generates and saves EDA charts using Matplotlib and OpenCV

import math
import cv2
import matplotlib.pyplot as plt
import pandas as pd
from pathlib import Path

from src.config import EDA_OUTPUT_DIR


class EDAService:
    """
    Generates EDA charts and outputs from the indexed image dataset.
    Takes the DataFrame built by DatasetIndexer and turns it into visuals.
    """

    def __init__(self, dataframe: pd.DataFrame, output_dir: Path = EDA_OUTPUT_DIR) -> None:
        self.df = dataframe
        self.output_dir = output_dir
        # Always ensure output folder exists
        self.output_dir.mkdir(parents=True, exist_ok=True)

    def generate_all(self) -> list:
        """
        Run all EDA outputs in one call.
        Called by the GUI when user clicks Generate EDA Charts.
        Returns list of saved file paths.
        """
        self.df['aspect_ratio'] = self.df['width'] / self.df['height']
        print("Generating all EDA outputs...")
        paths = [
            self._save_class_distribution(),
            self._save_pie_chart(),
            self._save_width_histogram(),
            self._save_height_histogram(),
            self._save_aspect_ratio(),
            self._save_channels_distribution(),
            self._save_scatter(),
            self._save_boxplot(),
            self._save_sample_grid(),
            self._save_top5_species(),
        ]
        self._export_csv_report()
        print("All EDA outputs saved.")
        return paths

    def build_summary(self) -> dict:
        """
        Returns key stats as a dictionary.
        Used by the GUI to populate the stats panel on startup.
        """
        counts = self.df["label"].value_counts()
        return {
            "total_images"  : len(self.df),
            "total_classes" : self.df["label"].nunique(),
            "mean_width"    : round(self.df["width"].mean(), 1),
            "mean_height"   : round(self.df["height"].mean(), 1),
            "most_common"   : counts.idxmax(),
            "least_common"  : counts.idxmin(),
        }

    # ── Individual chart methods ───────────────────────────────────────

    def _save_class_distribution(self) -> Path:
        """Bar chart of images per species."""
        plt.figure(figsize=(8, 5))
        self.df['label'].value_counts().plot(kind='bar')
        plt.title('Image Count per Category')
        plt.xlabel('Category')
        plt.ylabel('Number of Images')
        plt.xticks(rotation=45, ha="right")
        plt.tight_layout()
        output_path = self.output_dir / 'class_distribution.png'
        plt.savefig(output_path)
        plt.close()
        print(f"Saved: {output_path}")
        return output_path

    def _save_pie_chart(self) -> Path:
        """Pie chart of species proportions."""
        plt.figure(figsize=(7, 7))
        self.df['label'].value_counts().plot(kind='pie', autopct='%1.1f%%')
        plt.title('Category Distribution')
        plt.ylabel('')
        plt.tight_layout()
        output_path = self.output_dir / 'category_pie_chart.png'
        plt.savefig(output_path)
        plt.close()
        print(f"Saved: {output_path}")
        return output_path

    def _save_width_histogram(self) -> Path:
        """Histogram of image widths."""
        plt.figure(figsize=(8, 5))
        plt.hist(self.df['width'], bins=20, color="steelblue", edgecolor="white")
        plt.title('Image Width Distribution')
        plt.xlabel('Width (pixels)')
        plt.ylabel('Frequency')
        plt.tight_layout()
        output_path = self.output_dir / 'width_distribution.png'
        plt.savefig(output_path)
        plt.close()
        print(f"Saved: {output_path}")
        return output_path

    def _save_height_histogram(self) -> Path:
        """Histogram of image heights."""
        plt.figure(figsize=(8, 5))
        plt.hist(self.df['height'], bins=20, color="coral", edgecolor="white")
        plt.title('Image Height Distribution')
        plt.xlabel('Height (pixels)')
        plt.ylabel('Frequency')
        plt.tight_layout()
        output_path = self.output_dir / 'height_distribution.png'
        plt.savefig(output_path)
        plt.close()
        print(f"Saved: {output_path}")
        return output_path

    def _save_aspect_ratio(self) -> Path:
        """Histogram of aspect ratios."""
        plt.figure(figsize=(8, 5))
        plt.hist(self.df['aspect_ratio'], bins=20, color="mediumpurple", edgecolor="white")
        plt.title('Aspect Ratio Distribution')
        plt.xlabel('Aspect Ratio (width / height)')
        plt.ylabel('Frequency')
        plt.tight_layout()
        output_path = self.output_dir / 'aspect_ratio_distribution.png'
        plt.savefig(output_path)
        plt.close()
        print(f"Saved: {output_path}")
        return output_path

    def _save_channels_distribution(self) -> Path:
        """Bar chart of colour channels."""
        plt.figure(figsize=(6, 5))
        self.df['channels'].value_counts().plot(kind='bar', color="teal")
        plt.title('Image Channels Distribution')
        plt.xlabel('Channels (3 = colour, 1 = grayscale)')
        plt.ylabel('Count')
        plt.xticks(rotation=0)
        plt.tight_layout()
        output_path = self.output_dir / 'channels_distribution.png'
        plt.savefig(output_path)
        plt.close()
        print(f"Saved: {output_path}")
        return output_path

    def _save_scatter(self) -> Path:
        """Scatter plot of width vs height."""
        plt.figure(figsize=(8, 5))
        plt.scatter(self.df['width'], self.df['height'], alpha=0.4, color="steelblue")
        plt.title('Width vs Height')
        plt.xlabel('Width (pixels)')
        plt.ylabel('Height (pixels)')
        plt.tight_layout()
        output_path = self.output_dir / 'width_vs_height.png'
        plt.savefig(output_path)
        plt.close()
        print(f"Saved: {output_path}")
        return output_path

    def _save_boxplot(self) -> Path:
        """Boxplot of image dimensions."""
        plt.figure(figsize=(8, 5))
        plt.boxplot(
            [self.df['width'], self.df['height']],
            labels=['Width', 'Height']
        )
        plt.title('Width and Height Boxplot')
        plt.ylabel('Pixels')
        plt.tight_layout()
        output_path = self.output_dir / 'dimension_boxplot.png'
        plt.savefig(output_path)
        plt.close()
        print(f"Saved: {output_path}")
        return output_path

    def _save_sample_grid(self, sample_count: int = 9) -> Path:
        """Grid of random sample images."""
        sample_df = self.df.sample(
            min(sample_count, len(self.df)), random_state=42
        )
        n = len(sample_df)
        cols = math.ceil(math.sqrt(n))
        rows = math.ceil(n / cols)

        fig, axes = plt.subplots(rows, cols, figsize=(cols * 3.5, rows * 3.5))
        axes_flat = axes.flat if hasattr(axes, "flat") else [axes]

        for ax, (_, row) in zip(axes_flat, sample_df.iterrows()):
            image = cv2.imread(row["file_path"])
            if image is None:
                ax.set_title(f"{row['label']}\n(load error)", fontsize=8, color="red")
                ax.axis("off")
                continue
            image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
            ax.imshow(image)
            ax.set_title(row["label"], fontsize=8)
            ax.axis("off")

        for ax in list(axes_flat)[n:]:
            ax.axis("off")

        plt.suptitle("Sample Images from Dataset", fontsize=12)
        plt.tight_layout()
        output_path = self.output_dir / 'sample_grid.png'
        plt.savefig(output_path)
        plt.close()
        print(f"Saved: {output_path}")
        return output_path

    def _save_top5_species(self) -> Path:
        """Horizontal bar chart of top 5 species."""
        top5 = self.df["label"].value_counts().head(5)
        plt.figure(figsize=(10, 5))
        plt.barh(top5.index[::-1], top5.values[::-1], color="mediumseagreen")
        plt.title("Top 5 Most Common Species")
        plt.xlabel("Image Count")
        plt.tight_layout()
        output_path = self.output_dir / 'top5_species.png'
        plt.savefig(output_path)
        plt.close()
        print(f"Saved: {output_path}")
        return output_path

    def _export_csv_report(self) -> None:
        """Export summary statistics as a CSV file."""
        summary = self.df.describe()
        summary.to_csv(self.output_dir / 'eda_summary_report.csv')
        print(f"Saved: {self.output_dir / 'eda_summary_report.csv'}")