# species_selector.py
# Startup dialog that lets the user pick which species to load
# Minimum 3 species required before the main app opens

import tkinter as tk
from tkinter import messagebox
from pathlib import Path

from src.config import RAW_DATA_DIR


class SpeciesSelector(tk.Tk):
    """
    Startup window shown before the main app.
    Lets the user choose which species to include in the analysis.
    Minimum 3 species must be selected.
    """

    def __init__(self) -> None:
        super().__init__()
        self.title("Select Species to Analyse")
        self.geometry("420x550")
        self.configure(bg="#f0f0f0")
        self.resizable(False, False)

        # Result — filled when user confirms
        self.selected_species = None

        # Get available species from folder names (fast — no image reading)
        self.available = self._scan_species()

        if not self.available:
            messagebox.showerror(
                "No Data Found",
                f"No species folders found in:\n{RAW_DATA_DIR}\n\n"
                "Please check your dataset is placed inside data/raw/"
            )
            self.destroy()
            return

        self._build_ui()

    def _scan_species(self) -> list:
        """Read folder names from data/raw/ — no image loading needed."""
        if not RAW_DATA_DIR.exists():
            return []
        return sorted([
            p.name for p in RAW_DATA_DIR.iterdir() if p.is_dir()
        ])

    def _build_ui(self) -> None:
        # Header
        tk.Label(
            self, text="Macroinvertebrate Analysis",
            font=("Arial", 14, "bold"), bg="#2c3e50", fg="white",
            pady=12
        ).pack(fill="x")

        tk.Label(
            self,
            text="Select species to include in the analysis.\nMinimum 3 required.",
            font=("Arial", 10), bg="#f0f0f0", pady=8
        ).pack()

        # Select All / Deselect All buttons
        btn_frame = tk.Frame(self, bg="#f0f0f0")
        btn_frame.pack(pady=4)

        tk.Button(
            btn_frame, text="Select All",
            command=self._select_all,
            font=("Arial", 9), padx=8
        ).pack(side="left", padx=5)

        tk.Button(
            btn_frame, text="Deselect All",
            command=self._deselect_all,
            font=("Arial", 9), padx=8
        ).pack(side="left", padx=5)

        # Scrollable checkbox list
        canvas_frame = tk.Frame(self, bg="#f0f0f0")
        canvas_frame.pack(fill="both", expand=True, padx=20, pady=5)

        canvas = tk.Canvas(canvas_frame, bg="white", highlightthickness=0)
        scrollbar = tk.Scrollbar(canvas_frame, orient="vertical", command=canvas.yview)
        self.checkbox_frame = tk.Frame(canvas, bg="white")

        self.checkbox_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )

        canvas.create_window((0, 0), window=self.checkbox_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        scrollbar.pack(side="right", fill="y")
        canvas.pack(side="left", fill="both", expand=True)

        # Create one checkbox per species
        self.vars = {}
        for species in self.available:
            var = tk.BooleanVar(value=True)  # default all selected
            self.vars[species] = var
            tk.Checkbutton(
                self.checkbox_frame,
                text=species,
                variable=var,
                bg="white",
                anchor="w",
                font=("Arial", 10)
            ).pack(fill="x", padx=10, pady=2)

        # Confirm button
        tk.Button(
            self,
            text="Confirm Selection →",
            command=self._confirm,
            font=("Arial", 11, "bold"),
            bg="#2ecc71", fg="white",
            pady=8, relief="flat"
        ).pack(fill="x", padx=20, pady=12)

    def _select_all(self) -> None:
        for var in self.vars.values():
            var.set(True)

    def _deselect_all(self) -> None:
        for var in self.vars.values():
            var.set(False)

    def _confirm(self) -> None:
        selected = [s for s, var in self.vars.items() if var.get()]
        if len(selected) < 3:
            messagebox.showwarning(
                "Too Few Selected",
                f"Please select at least 3 species.\nYou selected {len(selected)}."
            )
            return
        self.selected_species = selected
        self.destroy()


def run_selector() -> list | None:
    """
    Launch the species selector and return the chosen species list.
    Returns None if the user closed without confirming.
    """
    selector = SpeciesSelector()
    selector.mainloop()
    return selector.selected_species