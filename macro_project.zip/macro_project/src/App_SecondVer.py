import tkinter as tk
from tkinter import ttk, messagebox
from pathlib import Path
from PIL import Image, ImageTk
import cv2

from src.services.dataset_indexer import DatasetIndexer
from src.services.eda_service_test import EDAService
from src.config import EDA_OUTPUT_DIR


class MacroApp(tk.Tk):
    def __init__(self) -> None:
        super().__init__()

        self.title("Macroinvertebrate Image Analysis System")
        self.geometry("950x700")
        self.configure(bg="#f0f0f0")
        self.status_var = tk.StringVar(value="Starting...")


        self._build_status_bar()

        self._status("Loading dataset...")


        try:
            self.indexer = DatasetIndexer()
            self.df = self.indexer.build_dataframe()
            self.eda = EDAService(self.df, EDA_OUTPUT_DIR)
            self.summary = self.eda.build_summary()
            self.class_names = self.indexer.get_class_names()
        except Exception as e:
            messagebox.showerror(
                "Startup Error",
                f"Failed to load dataset:\n{e}\n\nPlease check your data path and config."
            )
            self.destroy()
            return


        self._photo_refs = []

        self._build_header()
        self._build_stats_panel()
        self._build_controls()
        self._build_image_panel()

        self._status("Dataset loaded. Ready.")


    # UI Builder methods
    def _build_header(self) -> None:
        """Top title banner."""
        header = tk.Frame(self, bg="#2c3e50", pady=12)
        header.pack(fill="x")

        tk.Label(
            header,
            text="🦟 Macroinvertebrate Image Analysis System",
            font=("Arial", 16, "bold"),
            bg="#2c3e50",
            fg="white"
        ).pack()

    def _build_stats_panel(self) -> None:
        panel = tk.Frame(self, bg="#f0f0f0", pady=8)
        panel.pack(fill="x", padx=20)

        stats = [
            ("Total Images", self.summary["total_images"]),
            ("Species", self.summary["total_classes"]),
            ("Avg Width", f"{self.summary['mean_width']} px"),
            ("Avg Height", f"{self.summary['mean_height']} px"),
            ("Most Common", self.summary["most_common"]),
            ("Least Common", self.summary["least_common"]),
        ]

        for label, value in stats:
            box = tk.Frame(panel, bg="white", relief="groove", bd=1, padx=10, pady=8)
            box.pack(side="left", expand=True, fill="x", padx=5)
            tk.Label(box, text=str(value), font=("Arial", 11, "bold"), bg="white").pack()
            tk.Label(box, text=label, font=("Arial", 8), fg="gray", bg="white").pack()

    def _build_controls(self) -> None:
        controls = tk.Frame(self, bg="#f0f0f0", pady=8)
        controls.pack(fill="x", padx=20)

        # Species dropdown
        tk.Label(controls, text="Select Species:", bg="#f0f0f0",
                 font=("Arial", 10)).pack(side="left", padx=(0, 5))

        self.species_var = tk.StringVar(value=self.class_names[0])
        dropdown = ttk.Combobox(
            controls,
            textvariable=self.species_var,
            values=self.class_names,
            state="readonly",
            width=28
        )
        dropdown.pack(side="left", padx=5)

        # Buttons
        btn_style = {"font": ("Arial", 10), "padx": 10, "pady": 4, "relief": "flat"}

        tk.Button(
            controls, text="Show Sample Image",
            command=self.show_sample_image,
            bg="#3498db", fg="white", **btn_style
        ).pack(side="left", padx=5)

        tk.Button(
            controls, text="Generate EDA Charts",
            command=self.generate_eda,
            bg="#2ecc71", fg="white", **btn_style
        ).pack(side="left", padx=5)

        # browse all generated charts, not just the hardcoded class_distribution.png.
        self.chart_var = tk.StringVar(value="")
        self.chart_dropdown = ttk.Combobox(
            controls,
            textvariable=self.chart_var,
            state="readonly",
            width=22
        )
        self.chart_dropdown.pack(side="left", padx=5)
        self._refresh_chart_list()

        tk.Button(
            controls, text="View Chart",
            command=self.view_chart,
            bg="#9b59b6", fg="white", **btn_style
        ).pack(side="left", padx=5)

        tk.Button(
            controls, text="Show All Species Counts",
            command=self.show_species_table,
            bg="#e67e22", fg="white", **btn_style
        ).pack(side="left", padx=5)

    def _build_image_panel(self) -> None:
        self.image_frame = tk.Frame(self, bg="white", relief="sunken", bd=1)
        self.image_frame.pack(fill="both", expand=True, padx=20, pady=8)

        self.image_label = tk.Label(
            self.image_frame,
            text="Select a species and click 'Show Sample Image'\nor click 'Generate EDA Charts' to begin.",
            font=("Arial", 12),
            bg="white",
            fg="gray"
        )
        self.image_label.pack(expand=True)

    def _build_status_bar(self) -> None:
        tk.Label(
            self,
            textvariable=self.status_var,
            font=("Arial", 9),
            fg="gray",
            bg="#e0e0e0",
            anchor="w",
            padx=10
        ).pack(fill="x", side="bottom")


    # Button actions
    def show_sample_image(self) -> None:
        selected = self.species_var.get()
        species_df = self.df[self.df["label"] == selected]

        if species_df.empty:
            messagebox.showwarning("No Images", f"No images found for {selected}.")
            return

        row = species_df.sample(1).iloc[0]

        image = cv2.imread(row["file_path"])
        if image is None:
            messagebox.showerror("Error", "Could not load image.")
            return

        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        pil_image = Image.fromarray(image)
        pil_image.thumbnail((700, 500))

        photo = ImageTk.PhotoImage(pil_image)
        self._photo_refs.append(photo)

        self.image_label.configure(image=photo, text="")
        self._status(f"Showing sample image for: {selected}  |  "
                     f"Size: {row['width']}x{row['height']}px")

    def generate_eda(self) -> None:
        self._status("Generating EDA charts...")
        try:
            paths = self.eda.generate_all()
            self._refresh_chart_list()
            messagebox.showinfo(
                "EDA Complete",
                f"Generated {len(paths)} charts.\nSaved to: {EDA_OUTPUT_DIR}"
            )
            self._status(f"EDA charts saved to {EDA_OUTPUT_DIR}")
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def view_chart(self) -> None:
        chart_name = self.chart_var.get()
        if not chart_name:
            messagebox.showwarning(
                "No Chart Selected",
                "Generate EDA charts first, then select one from the dropdown."
            )
            return

        chart_path = EDA_OUTPUT_DIR / chart_name
        if not chart_path.exists():
            messagebox.showwarning("File Not Found", f"Could not find: {chart_path}")
            return

        pil_image = Image.open(chart_path)
        pil_image.thumbnail((880, 500))

        photo = ImageTk.PhotoImage(pil_image)
        self._photo_refs.append(photo)

        self.image_label.configure(image=photo, text="")
        self._status(f"Viewing: {chart_name}")

    def show_species_table(self) -> None:
        counts = (
            self.df["label"]
            .value_counts()
            .rename_axis("Species")
            .reset_index(name="Image Count")
        )

        window = tk.Toplevel(self)
        window.title("Species Image Counts")
        window.geometry("400x500")
        window.configure(bg="white")

        tk.Label(window, text="Species Image Counts",
                 font=("Arial", 12, "bold"), bg="white").pack(pady=10)

        frame = tk.Frame(window, bg="white")
        frame.pack(fill="both", expand=True, padx=10, pady=5)

        scrollbar = tk.Scrollbar(frame)
        scrollbar.pack(side="right", fill="y")

        listbox = tk.Listbox(frame, yscrollcommand=scrollbar.set,
                             font=("Courier", 10), bg="white", bd=0)
        listbox.pack(fill="both", expand=True)
        scrollbar.config(command=listbox.yview)

        for _, row in counts.iterrows():
            listbox.insert("end", f"  {row['Species']:<30} {row['Image Count']}")


    # Helpers
    def _refresh_chart_list(self) -> None:
        if EDA_OUTPUT_DIR.exists():
            charts = sorted(p.name for p in EDA_OUTPUT_DIR.glob("*.png"))
        else:
            charts = []

        self.chart_dropdown["values"] = charts
        if charts and not self.chart_var.get():
            self.chart_var.set(charts[0])

    def _status(self, message: str) -> None:
        self.status_var.set(message)
        self.update_idletasks()


def main() -> None:
    app = MacroApp()
    app.mainloop()


if __name__ == "__main__":
    main()
