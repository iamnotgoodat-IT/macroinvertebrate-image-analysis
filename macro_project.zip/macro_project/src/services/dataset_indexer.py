# DatasetIndexer.py
import cv2
import pandas as pd
from pathlib import Path

from src.config import RAW_DATA_DIR, EDA_OUTPUT_DIR, MODEL_OUTPUT_DIR, IMAGE_SIZE, SUPPORTED_IMAGE_FORMATS
from src.models.records import ImageRecord

class DatasetIndexer:
    def __init__(self, raw_data_dir=RAW_DATA_DIR) -> None:
        self.raw_data_dir = raw_data_dir
        self._records = []
        

    def build_dataframe(self) -> pd.DataFrame:
        """Build a DataFrame from the indexed image records."""
        self._records = []

        for file_path in self.raw_data_dir.rglob("*"):
            if file_path.suffix.lower() not in SUPPORTED_IMAGE_FORMATS:
                continue

            image = cv2.imread(str(file_path))
            if image is None:
                continue

            height, width = image.shape[:2]
            channels = image.shape[2] if len(image.shape) == 3 else 1
            label = file_path.parent.name

            self._records.append(ImageRecord(
                file_path=file_path,
                label=label,
                width=width,
                height=height,
                channels=channels
            ))

        if not self._records:
            raise FileNotFoundError(f"No supported image files found in {self.raw_data_dir}\n"
                                    "Make sure the kaggle dataset is downloaded and extracted correctly and is inside data/raw.")
        return self._to_dataframe()
    
    def get_class_names(self) -> list:
        """Get a list of unique class names from the indexed records."""
        return sorted(set(record.label for record in self._records))
    
    def get_summary(self) -> dict:
        """Returns basic summary statistics about the dataset."""
        if not self._records:
            self.build_dataframe()
        
        widths = [record.width for record in self._records]
        heights = [record.height for record in self._records]

        return {
            "total_images": len(self._records),
            "total_classes": len(self.get_class_names()),
            "average_width": sum(widths) / len(widths) if widths else 0,
            "average_height": sum(heights) / len(heights) if heights else 0,
        }
    
    def _to_dataframe(self) -> pd.DataFrame:
        rows = []
        for record in self._records:
            rows.append({
                "file_path": str(record.file_path),  # ← add str() here
                "label": record.label,
                "width": record.width,
                "height": record.height,
                "channels": record.channels
            })
        return pd.DataFrame(rows)