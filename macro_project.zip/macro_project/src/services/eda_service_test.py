import math
from pathlib import Path

import cv2
import matplotlib.pyplot as plt
import pandas as pd

from src.config import EDA_OUTPUT_DIR


class EDAService:
    """
    Generates EDA charts and outputs from the indexed image dataset.
    Takes the DataFrame built by DatasetIndexer and turns it into visuals.
    """

    def __init__(self, dataframe: pd.DataFrame, output_dir: Path = EDA_OUTPUT_DIR) -> None:
        self.dataframe = dataframe
        self.output_dir = output_dir

        # Make sure the output folder exists before saving anything
        self.output_dir.mkdir(parents=True, exist_ok=True)

    def save_class_distribution(self) -> Path:
        """
        Bar chart showing how many images exist per species.
        Useful for spotting class imbalance in the dataset.
        """
        counts = self.dataframe["label"].value_counts()

        plt.figure(figsize=(14, 6))
        plt.bar(counts.index, counts.values, color="steelblue")
        plt.xticks(rotation=45, ha="right")
        plt.title("Number of Images per Species")
        plt.xlabel("Species")
        plt.ylabel("Image Count")
        plt.tight_layout()

        output_path = self.output_dir / "class_distribution.png"
        plt.savefig(output_path)
        plt.close()

        print(f"Saved: {output_path}")
        return output_path

    def save_size_distribution(self) -> Path:
        """
        Two histograms showing the spread of image widths and heights.
        Helps justify why we resize all images to a fixed size.
        """
        fig, axes = plt.subplots(1, 2, figsize=(12, 5))

        axes[0].hist(self.dataframe["width"], bins=20, color="steelblue", edgecolor="white")
        axes[0].set_title("Image Width Distribution")
        axes[0].set_xlabel("Width (pixels)")
        axes[0].set_ylabel("Count")

        axes[1].hist(self.dataframe["height"], bins=20, color="coral", edgecolor="white")
        axes[1].set_title("Image Height Distribution")
        axes[1].set_xlabel("Height (pixels)")
        axes[1].set_ylabel("Count")

        plt.tight_layout()

        output_path = self.output_dir / "size_distribution.png"
        plt.savefig(output_path)
        plt.close()

        print(f"Saved: {output_path}")
        return output_path

    def save_sample_grid(self, sample_count: int = 9) -> Path:
        """
        Grid of random sample images from the dataset.
        Gives a quick visual feel of what the data looks like.
        """
        sample_df = self.dataframe.sample(
            min(sample_count, len(self.dataframe)),
            random_state=42
        )

        # hardcoding 3x3, so any sample_count value produces a sensible layout.
        n = len(sample_df)
        cols = math.ceil(math.sqrt(n))
        rows = math.ceil(n / cols)

        fig, axes = plt.subplots(rows, cols, figsize=(cols * 3.5, rows * 3.5))
        axes_flat = axes.flat if hasattr(axes, "flat") else [axes]

        for ax, (_, row) in zip(axes_flat, sample_df.iterrows()):
            image = cv2.imread(row["file_path"])
            if image is None:
                ax.set_title(f"{row['label']}\n(load error)", fontsize=8, color="red")
                ax.axis("off")
                continue
            image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
            ax.imshow(image)
            ax.set_title(row["label"], fontsize=8)
            ax.axis("off")

        # Turn off any leftover empty subplots
        for ax in list(axes_flat)[n:]:
            ax.axis("off")

        plt.suptitle("Sample Images from Dataset", fontsize=12)
        plt.tight_layout()

        output_path = self.output_dir / "sample_grid.png"
        plt.savefig(output_path)
        plt.close()

        print(f"Saved: {output_path}")
        return output_path

    def save_top5_species(self) -> Path:
        """
        Horizontal bar chart of the top 5 most common species.
        Clean visual for the presentation.
        """
        top5 = self.dataframe["label"].value_counts().head(5)

        plt.figure(figsize=(10, 5))
        plt.barh(top5.index[::-1], top5.values[::-1], color="mediumseagreen")
        plt.title("Top 5 Most Common Species")
        plt.xlabel("Image Count")
        plt.tight_layout()

        output_path = self.output_dir / "top5_species.png"
        plt.savefig(output_path)
        plt.close()

        print(f"Saved: {output_path}")
        return output_path

    def generate_all(self) -> list:
        """
        Run all EDA outputs in one call.
        Returns a list of saved file paths.
        """
        print("Generating all EDA outputs...")
        paths = [
            self.save_class_distribution(),
            self.save_size_distribution(),
            self.save_sample_grid(),
            self.save_top5_species(),
        ]
        print("All EDA outputs saved.")
        return paths

    def build_summary(self) -> dict:
        """
        Returns key stats as a dictionary.
        Used by the GUI to populate the stats panel.
        """
        counts = self.dataframe["label"].value_counts()

        return {
            "total_images": len(self.dataframe),
            "total_classes": self.dataframe["label"].nunique(),
            "mean_width": round(self.dataframe["width"].mean(), 1),
            "mean_height": round(self.dataframe["height"].mean(), 1),
            "most_common": counts.idxmax(),
            "least_common": counts.idxmin(),
        }

